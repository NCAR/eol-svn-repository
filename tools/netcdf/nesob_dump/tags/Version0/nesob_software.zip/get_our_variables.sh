nesob_dump -v base_time,time_offset,lat,lon,alt,sfc_temp -l 50000 ./raw/Dsgpmfr10mC1.a1.960824.*.cdf > 960824.dump
# nesob_dump -v base_time,time_offset,lat,lon,alt,sfc_temp -l 50000 ./raw/Dsgpmfr10mC1.a1.960829.*.cdf > 960829.dump
# nesob_dump -v base_time,time_offset,lat,lon,alt,sfc_temp -l 50000 ./raw/Dsgpmfr10mC1.a1.960830.*.cdf > 960830.dump
# nesob_dump -v base_time,time_offset,lat,lon,alt,sfc_temp -l 50000 ./raw/Dsgpmfr10mC1.a1.960831.*.cdf > 960831.dump
# nesob_dump -v base_time,time_offset,lat,lon,alt,sfc_temp -l 50000 ./raw/Dsgpmfr10mC1.a1.960901.*.cdf > 960901.dump
# nesob_dump -v base_time,time_offset,lat,lon,alt,sfc_temp -l 50000 ./raw/Dsgpmfr10mC1.a1.960902.*.cdf > 960902.dump
